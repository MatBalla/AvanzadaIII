//invocaion básica
fun saludar(){
    println("Bienvenido a la Progra Funcional")
}
//Invoación en secuencia
fun iniciar(){
    println("Iniciar")
}

fun procesar(){
    println("Procesando")
}

fun finalizar(){
    println("Finalizando")
}

//Métodos con parámetros
fun imprimirNombre(nomber:String, edad:Int){
    println("El nombre es: $nomber y la edad es: $edad" )
}
fun calcularArea(base:Double, altura:Double){
    val area = (base*altura)/2
    println("El area es: $area")
}

fun sumar(a:Int, b:Int):Int{
    return a+b
}

fun sumar2(a:Int, b:Int):Int = a+b //este es mejor


//numero par o no
fun esPar(a:Int): Boolean = a%2 == 0

//promedio estudiante 3 calificaciones

fun promedio(a: Double, b: Double, c:Double):Double =(a+b+c)/3

class Calculadora{ //Clase comun y corriente
    fun restar(a: Int, b: Int): Int = a-b
}

//Clase que representa a un objeto
class Persona(var nombre:String, var edad:Int){
    fun hablar() = println("La persona1 se llama $nombre")
}

fun main() {

    saludar()

    iniciar()
    procesar()
    finalizar()

    imprimirNombre("Mateo", 22)

    calcularArea(12.0, 5.0)

    println(sumar(1, 2))
    println(sumar2(1, 2))

    println(esPar(23123))

    println(promedio(20.0, 16.0, 17.0))


    //Instanciar
    val calculadora = Calculadora()
    println(calculadora.restar(2,4))


}