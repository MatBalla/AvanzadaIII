    //funcion que reciba los cofeicientes: a, b, y c de una ecuacion cuadratica
    // La función debe calcular el discriminante = b*b-4ac
    //Y determinar: si tiene dos soluciones reales diferentes
    //Si tiene una solucion real doble y si no tiene soluciones reales
    //recibir los coeficientes, calcular el discriminnte
    fun discriminante2(a: Double, b:Double, c: Double): Double{
        return (b*b)-4*a*c;
        //ver foto
    }


    //Desarollar una funcion que reciba las coordenadas de dos puntos en un plano cartesiano y
    //calcula el punto medio del segmento
    //Mx=x1+x2/2 y MY=y1+y2/2
    //La función debe devolver las dos coordenadas del punto medio

    fun coordenadas(a: Double, b:Double, c: Double, d:Double): Double{

    //ver foto
        return 0.0;
    }


fun main(){
    println(discriminante2(1.0, -5.0, 6.0 ))

}